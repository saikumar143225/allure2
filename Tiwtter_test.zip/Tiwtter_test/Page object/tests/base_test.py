import pytest
from pageObject.config.config_file import ConfigData
from selenium import webdriver


@pytest.mark.usefixtures('init_driver')
class BaseTest:

    @pytest.fixture(scope='function')
    def init_driver(self, request):
        web_driver = webdriver.Chrome(executable_path=ConfigData.CHROME_DRIVER_PATH)
        request.cls.driver = web_driver
        yield
        web_driver.quit()