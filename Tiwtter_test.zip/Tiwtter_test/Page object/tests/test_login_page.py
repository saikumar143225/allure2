import pytest
import allure
from pageObject.pages.loginpage import LoginPage
from pageObject.tests.base_test import BaseTest
from pageObject.config.config_xlsx import ConfigXlsxData


class TestLoginPage(BaseTest):

    def test_Twitter_title(self):
        self.login_page = LoginPage(self.driver)
        print(self.login_page.get_title())
        assert self.login_page.get_title() == 'Twitter'

    def test_login_page(self):
        self.login_page = LoginPage(self.driver)
        self.username = ConfigXlsxData.get_usernames()
        self.password = ConfigXlsxData.get_password()
        self.login_page.do_login(self.username[0], self.password[0])
        assert self.login_page.get_error_message() == """Wrong Password"""