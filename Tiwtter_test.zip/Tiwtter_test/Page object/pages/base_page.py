from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys


class BasePage:

    def __init__(self, driver):
        self.driver = driver
        self.driver.maximize_window()

    def do_click(self, by_locator):
        WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(by_locator)).click()

    def do_send_keys(self, by_locator, text):
        WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(by_locator)).send_keys(text)

    def do_click(self, by_locator):
        WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(by_locator)).click()

    def do_send_keys(self, by_locator, text):
        WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(by_locator)).send_keys(text)

    def do_click(self, by_locator):
        WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(by_locator)).click()

    def find_element_by_xpath(self, by_locator):
        return WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(by_locator))

    def clear_text(self, by_locator):
        return WebDriverWait(self.driver, 15).until(EC.presence_of_all_elements_located(by_locator)).clear()

    def get_element_text(self, by_locator):
        text = WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(by_locator)).text
        return text

    def get_title(self):
        return self.driver.title

    def is_visible(self, by_locator):
        element = WebDriverWait(self.driver, 15).until(EC.visibility_of_element_located(by_locator))
        return bool(element)

    def go_back(self):
        self.driver.back()

    def go_forward(self):
        self.driver.forward()
