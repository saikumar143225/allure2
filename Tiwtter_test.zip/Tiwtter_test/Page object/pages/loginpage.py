from pageObject.pages.base_page import BasePage
from pageObject.config.config_xlsx import ConfigXlsxData
from selenium.webdriver.common.by import By


class LoginPage(BasePage):
    EMAIL = (By.XPATH, '//div[@class="css-1dbjc4n r-18u37iz r-16y2uox r-1wbh5a2 r-1wzrnnt r-1udh08x r-xd6kpl r-1pn2ns4 r-ttdzmv"]')
    NEXT_BUTTON = (By.XPATH, '//div[@class="css-901oao r-1awozwy r-jwli3a r-6koalj r-18u37iz r-16y2uox r-37j5jr r-a023e6 r-b88u0q r-1777fci r-rjixqe r-bcqeeo r-q4m81j r-qvutc0"]')
    PASSWORD = (By.XPATH, '//input[@class="r-30o5oe r-1niwhzg r-17gur6a r-1yadl64 r-deolkf r-homxoj r-poiln3 r-7cikom r-1ny4l3l r-t60dpp r-1dz5y72 r-fdjqy7 r-13qz1uu"]')
    SUBMIT_BUTTON=(By.XPATH,'//div[@class ="css-901oao r-1awozwy r-6koalj r-18u37iz r-16y2uox r-37j5jr r-a023e6 r-b88u0q r-1777fci r-rjixqe r-bcqeeo r-q4m81j r-qvutc0"][3]')
    PASSWORD_INCORRET_MESSAGE = (By.XPATH, '//div[@id="error_box"]')


    def __init__(self, driver):
        super().__init__(driver)
        self.driver.get(ConfigXlsxData.BASE_URL)

    def do_login(self, username, password):
        self.do_send_keys(self.EMAIL, username)
        self.do_click(self.NEXT_BUTTON)
        self.do_send_keys(self.PASSWORD, password)
        self.do_click(self.SUBMIT_BUTTON)



    def get_error_message(self):
        return self.get_element_text(self.PASSWORD_INCORRET_MESSAGE)

    def is_submit_button_visible(self):
        return self.is_visible(self.SUBMIT_BUTTON)
