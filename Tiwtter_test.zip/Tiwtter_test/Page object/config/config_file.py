
class ConfigData:

    CHROME_DRIVER_PATH = "C:\\Users\\Sai Kumar\\Desktop\\my notes\\chromedriver"
    TWITTER_HOME_URL = 'https://www.facebook.com/'
