import xlrd

class ConfigXlsxData:
    BASE_URL ="https://twitter.com/i/flow/login"
    book = xlrd.open_workbook('C:\\Users\\Sai Kumar\\Desktoptask1\\Tiwtter_test\\Page object\\excel\\sample.xlsx')
    sheet1 = book.sheet_by_name('Sheet1')
    row_count = sheet1.nrows
    col_count = sheet1.ncols

    @staticmethod
    def get_usernames():
        rows = ConfigXlsxData.row_count
        user_list = []
        for row in range(1, rows):
            username = ConfigXlsxData.sheet1.cell_value(row, 0)
            user_list.append(username)
        return user_list

    @staticmethod
    def get_password():
        rows = ConfigXlsxData.row_count
        password_list = []
        for row in range(1, rows):
            password = ConfigXlsxData.sheet1.cell_value(row, 1)
            password_list.append(password)
        return password_list

print(ConfigXlsxData.get_usernames())
print(ConfigXlsxData.get_password())